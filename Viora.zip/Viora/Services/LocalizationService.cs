namespace Viora.Services;

/// <summary>
/// ILocalizationService defines the contract for language switching.
/// The app supports English (LTR) and Arabic (RTL).
/// </summary>
public interface ILocalizationService
{
    /// <summary>Currently selected language code: "en" or "ar".</summary>
    string CurrentLanguage { get; }

    /// <summary>True when Arabic is active (RTL layout required).</summary>
    bool IsArabic { get; }

    /// <summary>Switch the active language and persist the choice.</summary>
    void SetLanguage(string languageCode);

    /// <summary>
    /// Return the localized string for a given key.
    /// Falls back to the key itself if no translation is found.
    /// </summary>
    string Get(string key);
}

/// <summary>
/// LocalizationService provides English and Arabic translations
/// for every UI string in the Viora app.
/// Add new strings to both dictionaries below.
/// </summary>
public class LocalizationService : ILocalizationService
{
    // ── Current language (default English) ────────────────────────────
    public string CurrentLanguage { get; private set; } = "en";
    public bool IsArabic => CurrentLanguage == "ar";

    // ── English strings ────────────────────────────────────────────────
    private static readonly Dictionary<string, string> English = new()
    {
        // Welcome page
        ["welcome_title"]          = "Welcome to Viora",
        ["welcome_subtitle"]       = "Accessibility Platform",
        ["welcome_instructions"]   = "Press 1 for English or 2 for Arabic",
        ["welcome_voice_prompt"]   = "Press 1 for English or press 2 for Arabic",

        // Sign In page
        ["signin_title"]           = "Sign In",
        ["signin_email"]           = "Email Address",
        ["signin_password"]        = "Password",
        ["signin_button"]          = "Sign In",
        ["signin_no_account"]      = "Don't have an account?",
        ["signup_link"]            = "Sign Up",
        ["signin_voice_prompt"]    = "Enter your email and password to sign in. Press Enter to sign up for a new account.",

        // Sign Up page
        ["signup_title"]           = "Create Account",
        ["signup_name"]            = "Full Name",
        ["signup_email"]           = "Email Address",
        ["signup_password"]        = "Password",
        ["signup_confirm"]         = "Confirm Password",
        ["signup_button"]          = "Create Account",
        ["signup_has_account"]     = "Already have an account?",
        ["signin_link"]            = "Sign In",
        ["signup_voice_prompt"]    = "Fill in your details to create a new account.",

        // Home page
        ["home_welcome"]           = "Welcome back",
        ["home_role"]              = "Role: Visually Impaired User",
        ["quick_actions"]          = "Quick Actions",
        ["recent_uploads"]         = "Recent Uploads",
        ["voice_request"]          = "Voice Request",
        ["upload_file"]            = "Upload File",
        ["image_analysis"]         = "Image Analysis",
        ["quick_voice_command"]    = "Quick Voice Command",
        ["home_voice_prompt"]      = "Home page. Say a command or press a quick action. Voice Request, Upload File, Image Analysis, or Quick Voice Command.",

        // Nav sidebar
        ["nav_home"]               = "Home",
        ["nav_voice_request"]      = "Voice Request",
        ["nav_chat"]               = "Chat Assistance",
        ["nav_upload"]             = "Upload File",
        ["nav_image_analysis"]     = "Image Analysis",
        ["nav_logout"]             = "Logout",

        // Voice Request page
        ["voice_assistant"]        = "Voice Assistant",
        ["tap_to_speak"]           = "Click to start voice command",
        ["suggested_commands"]     = "Suggested Commands",
        ["cmd_new_request"]        = "\"Create a new help request\"",
        ["cmd_view_messages"]      = "\"View my messages\"",
        ["cmd_read_file"]          = "\"Read my uploaded file\"",
        ["voice_page_prompt"]      = "Voice assistant page. Tap the microphone to start speaking.",

        // Chat Assistance page
        ["ai_assistant"]           = "AI Assistant",
        ["ai_subtitle"]            = "Ask questions or request help — I'm here for you",
        ["ai_online"]              = "Online",
        ["chat_placeholder"]       = "Type your question or request...",
        ["quick_how_label"]        = "How do I read a label?",
        ["quick_medication"]       = "Help with medication",
        ["quick_what_can"]         = "What can you do?",
        ["quick_voice_input"]      = "Use voice input",
        ["chat_page_prompt"]       = "Chat assistance page. Type or speak your question to the AI assistant.",

        // Upload File page
        ["upload_title"]           = "Upload File",
        ["drop_file_here"]         = "Drop file here or click to upload",
        ["supported_formats"]      = "Supports PDF, DOCX, TXT, and images",
        ["select_file"]            = "Select File",
        ["upload_page_prompt"]     = "Upload file page. Select a file to upload for analysis.",

        // Image Analysis page
        ["image_analysis_title"]   = "Image Analysis",
        ["upload_image"]           = "Upload Image for Analysis",
        ["drop_image_here"]        = "Drop image here or click to upload",
        ["supported_image_formats"]= "Supports JPG, PNG, and GIF",
        ["select_image"]           = "Select Image",
        ["analysis_options"]       = "Analysis Options",
        ["ocr_extract"]            = "OCR - Extract Text",
        ["ai_description"]         = "AI Description",
        ["analyze_button"]         = "Analyze Image",
        ["image_page_prompt"]      = "Image analysis page. Upload an image to extract text or get an AI description.",

        // Common
        ["loading"]                = "Loading...",
        ["error_generic"]          = "Something went wrong. Please try again.",
        ["logout_confirm"]         = "Are you sure you want to log out?",
        ["yes"]                    = "Yes",
        ["no"]                     = "No",
    };

    // ── Arabic strings ─────────────────────────────────────────────────
    private static readonly Dictionary<string, string> Arabic = new()
    {
        // Welcome page
        ["welcome_title"]          = "مرحباً بك في Viora",
        ["welcome_subtitle"]       = "منصة إمكانية الوصول",
        ["welcome_instructions"]   = "اضغط 1 للإنجليزية أو 2 للعربية",
        ["welcome_voice_prompt"]   = "اضغط 1 للإنجليزية أو اضغط 2 للعربية",

        // Sign In page
        ["signin_title"]           = "تسجيل الدخول",
        ["signin_email"]           = "البريد الإلكتروني",
        ["signin_password"]        = "كلمة المرور",
        ["signin_button"]          = "دخول",
        ["signin_no_account"]      = "ليس لديك حساب؟",
        ["signup_link"]            = "إنشاء حساب",
        ["signin_voice_prompt"]    = "أدخل بريدك الإلكتروني وكلمة المرور للدخول. اضغط Enter لإنشاء حساب جديد.",

        // Sign Up page
        ["signup_title"]           = "إنشاء حساب",
        ["signup_name"]            = "الاسم الكامل",
        ["signup_email"]           = "البريد الإلكتروني",
        ["signup_password"]        = "كلمة المرور",
        ["signup_confirm"]         = "تأكيد كلمة المرور",
        ["signup_button"]          = "إنشاء حساب",
        ["signup_has_account"]     = "لديك حساب بالفعل؟",
        ["signin_link"]            = "تسجيل الدخول",
        ["signup_voice_prompt"]    = "أدخل بياناتك لإنشاء حساب جديد.",

        // Home page
        ["home_welcome"]           = "مرحباً بعودتك",
        ["home_role"]              = "الدور: مستخدم ضعيف البصر",
        ["quick_actions"]          = "الإجراءات السريعة",
        ["recent_uploads"]         = "الملفات المحملة مؤخراً",
        ["voice_request"]          = "طلب صوتي",
        ["upload_file"]            = "تحميل ملف",
        ["image_analysis"]         = "تحليل الصورة",
        ["quick_voice_command"]    = "أمر صوتي سريع",
        ["home_voice_prompt"]      = "الصفحة الرئيسية. قل أمراً أو اضغط أحد الإجراءات السريعة. طلب صوتي، تحميل ملف، تحليل صورة، أو أمر صوتي سريع.",

        // Nav sidebar
        ["nav_home"]               = "الرئيسية",
        ["nav_voice_request"]      = "طلب صوتي",
        ["nav_chat"]               = "مساعدة الدردشة",
        ["nav_upload"]             = "تحميل ملف",
        ["nav_image_analysis"]     = "تحليل الصورة",
        ["nav_logout"]             = "تسجيل الخروج",

        // Voice Request page
        ["voice_assistant"]        = "مساعد صوتي",
        ["tap_to_speak"]           = "انقر لبدء الأمر الصوتي",
        ["suggested_commands"]     = "الأوامر المقترحة",
        ["cmd_new_request"]        = "\"إنشاء طلب مساعدة جديد\"",
        ["cmd_view_messages"]      = "\"عرض رسائلي\"",
        ["cmd_read_file"]          = "\"اقرأ ملفي المرفوع\"",
        ["voice_page_prompt"]      = "صفحة المساعد الصوتي. انقر على الميكروفون للبدء.",

        // Chat Assistance page
        ["ai_assistant"]           = "مساعد الذكاء الاصطناعي",
        ["ai_subtitle"]            = "اسأل أسئلتك أو اطلب المساعدة — أنا هنا لمساعدتك",
        ["ai_online"]              = "متصل",
        ["chat_placeholder"]       = "اكتب سؤالك أو طلبك...",
        ["quick_how_label"]        = "كيف أقرأ الملصق؟",
        ["quick_medication"]       = "مساعدة بشأن الدواء",
        ["quick_what_can"]         = "ماذا يمكنك أن تفعل؟",
        ["quick_voice_input"]      = "استخدام الإدخال الصوتي",
        ["chat_page_prompt"]       = "صفحة مساعدة الدردشة. اكتب أو تحدث لطرح سؤالك على المساعد الذكي.",

        // Upload File page
        ["upload_title"]           = "تحميل ملف",
        ["drop_file_here"]         = "أسقط الملف هنا أو انقر للتحميل",
        ["supported_formats"]      = "يدعم PDF وDOCX وTXT والصور",
        ["select_file"]            = "اختر ملفاً",
        ["upload_page_prompt"]     = "صفحة تحميل الملف. اختر ملفاً للتحميل والتحليل.",

        // Image Analysis page
        ["image_analysis_title"]   = "تحليل الصورة",
        ["upload_image"]           = "تحميل صورة للتحليل",
        ["drop_image_here"]        = "أسقط الصورة هنا أو انقر للتحميل",
        ["supported_image_formats"]= "يدعم JPG وPNG وGIF",
        ["select_image"]           = "اختر صورة",
        ["analysis_options"]       = "خيارات التحليل",
        ["ocr_extract"]            = "OCR - استخراج النص",
        ["ai_description"]         = "وصف الذكاء الاصطناعي",
        ["analyze_button"]         = "تحليل الصورة",
        ["image_page_prompt"]      = "صفحة تحليل الصور. قم بتحميل صورة لاستخراج النص أو الحصول على وصف.",

        // Common
        ["loading"]                = "جارٍ التحميل...",
        ["error_generic"]          = "حدث خطأ. يرجى المحاولة مرة أخرى.",
        ["logout_confirm"]         = "هل أنت متأكد أنك تريد تسجيل الخروج؟",
        ["yes"]                    = "نعم",
        ["no"]                     = "لا",
    };

    /// <inheritdoc />
    public void SetLanguage(string languageCode)
    {
        CurrentLanguage = languageCode == "ar" ? "ar" : "en";

        // Persist the choice so next launch remembers it
        Preferences.Default.Set("app_language", CurrentLanguage);
    }

    /// <inheritdoc />
    public string Get(string key)
    {
        var dict = IsArabic ? Arabic : English;
        return dict.TryGetValue(key, out var value) ? value : key;
    }

    /// <summary>
    /// Load the persisted language on startup (called in App constructor).
    /// </summary>
    public void LoadSavedLanguage()
    {
        var saved = Preferences.Default.Get("app_language", "en");
        CurrentLanguage = saved;
    }
}
