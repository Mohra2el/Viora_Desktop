using Viora.Models;

namespace Viora.Services;

/// <summary>
/// IAuthService defines the authentication contract.
/// Replace the mock implementation with a real backend call as needed.
/// </summary>
public interface IAuthService
{
    Task<(bool success, string message)> SignInAsync(string email, string password);
    Task<(bool success, string message)> SignUpAsync(string name, string email, string password);
    void SignOut();
    UserModel? CurrentUser { get; }
    bool IsAuthenticated { get; }
}

/// <summary>
/// AuthService provides a mock implementation that always succeeds.
/// Replace the body of SignInAsync / SignUpAsync with real HTTP calls.
/// </summary>
public class AuthService : IAuthService
{
    public UserModel? CurrentUser { get; private set; }
    public bool IsAuthenticated => CurrentUser != null;

    public async Task<(bool success, string message)> SignInAsync(string email, string password)
    {
        // Simulate network delay
        await Task.Delay(800);

        // ── Real implementation: POST /api/auth/signin ──────────────────
        // Replace this block with actual HTTP logic when backend is ready.
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            return (false, "Please enter your email and password.");

        // Mock successful sign-in — any non-empty credentials work
        CurrentUser = new UserModel
        {
            Name  = "John Doe",
            Email = email,
            Role  = "Visually Impaired User"
        };

        return (true, "Welcome back!");
    }

    public async Task<(bool success, string message)> SignUpAsync(string name, string email, string password)
    {
        await Task.Delay(800);

        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            return (false, "Please fill in all fields.");

        // Mock successful sign-up
        CurrentUser = new UserModel
        {
            Name  = name,
            Email = email,
            Role  = "Visually Impaired User"
        };

        return (true, "Account created successfully!");
    }

    public void SignOut() => CurrentUser = null;
}
