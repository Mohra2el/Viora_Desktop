namespace Viora.Services;

/// <summary>
/// IVoiceGuidanceService defines text-to-speech for accessibility guidance.
/// Every page and interactive element should call Speak() so visually impaired
/// users always know where they are and what they can do.
/// </summary>
public interface IVoiceGuidanceService
{
    /// <summary>Speak the given text aloud using the device TTS engine.</summary>
    Task SpeakAsync(string text, CancellationToken cancellationToken = default);

    /// <summary>Stop any currently playing speech immediately.</summary>
    Task StopAsync();

    /// <summary>True while the engine is speaking.</summary>
    bool IsSpeaking { get; }
}

/// <summary>
/// VoiceGuidanceService wraps .NET MAUI's built-in TextToSpeech API.
/// On Windows it uses the SAPI/WinRT speech engine.
/// On Android/iOS it uses the native TTS engine.
/// </summary>
public class VoiceGuidanceService : IVoiceGuidanceService
{
    // Token source lets us cancel an ongoing utterance before starting a new one
    private CancellationTokenSource? _cts;

    public bool IsSpeaking { get; private set; }

    /// <inheritdoc />
    public async Task SpeakAsync(string text, CancellationToken cancellationToken = default)
    {
        // Cancel any speech already in progress
        await StopAsync();

        if (string.IsNullOrWhiteSpace(text)) return;

        // Create a new linked token so callers can also cancel
        _cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        try
        {
            IsSpeaking = true;

            var settings = new SpeechOptions
            {
                // Slightly slower for accessibility
                Volume = 1.0f,
                Pitch  = 1.0f,
            };

            await TextToSpeech.Default.SpeakAsync(text, settings, _cts.Token);
        }
        catch (TaskCanceledException)
        {
            // Normal — speech was stopped intentionally
        }
        catch (Exception ex)
        {
            // Log but don't crash; voice guidance is enhancement, not core function
            System.Diagnostics.Debug.WriteLine($"[VoiceGuidance] Error: {ex.Message}");
        }
        finally
        {
            IsSpeaking = false;
        }
    }

    /// <inheritdoc />
    public async Task StopAsync()
    {
        if (_cts != null)
        {
            await _cts.CancelAsync();
            _cts.Dispose();
            _cts = null;
        }

        IsSpeaking = false;
    }
}
