using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace Viora.Services;

/// <summary>
/// IAIService defines AI-powered features:
/// - Chat assistance
/// - Image analysis (OCR + description)
/// </summary>
public interface IAIService
{
    Task<string> ChatAsync(string userMessage, List<ChatMessage>? history = null);
    Task<string> AnalyzeImageAsync(byte[] imageBytes, string mimeType, bool doOcr, bool doDescription);
}

/// <summary>
/// Represents a single turn in a conversation.
/// </summary>
public record ChatMessage(string Role, string Content);

/// <summary>
/// AIService calls the Anthropic Claude API for text chat and vision tasks.
/// Set your API key in the app (Preferences / environment variable) before shipping.
/// </summary>
public class AIService : IAIService
{
    // ── Configuration ──────────────────────────────────────────────────
    // In production: load from secure storage or environment variable
    private const string ApiUrl   = "https://api.anthropic.com/v1/messages";
    private const string Model    = "claude-sonnet-4-6";
    private const string ApiKey   = "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"; // ← Replace or inject

    private readonly HttpClient _http;

    public AIService()
    {
        _http = new HttpClient();
        _http.DefaultRequestHeaders.Add("x-api-key", ApiKey);
        _http.DefaultRequestHeaders.Add("anthropic-version", "2023-06-01");
    }

    /// <inheritdoc />
    public async Task<string> ChatAsync(string userMessage, List<ChatMessage>? history = null)
    {
        // Build the messages array (history + new message)
        var messages = new List<object>();

        if (history != null)
        {
            foreach (var msg in history)
                messages.Add(new { role = msg.Role, content = msg.Content });
        }

        messages.Add(new { role = "user", content = userMessage });

        var body = new
        {
            model      = Model,
            max_tokens = 1024,
            system     = "You are Viora, an AI accessibility assistant helping visually impaired users. " +
                         "Be concise, warm, and clear. Always describe what you are doing.",
            messages
        };

        var json     = JsonSerializer.Serialize(body);
        var content  = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await _http.PostAsync(ApiUrl, content);
        var result   = await response.Content.ReadAsStringAsync();

        // Parse the response
        using var doc   = JsonDocument.Parse(result);
        var text        = doc.RootElement
                            .GetProperty("content")[0]
                            .GetProperty("text")
                            .GetString();

        return text ?? "I'm sorry, I couldn't process that request.";
    }

    /// <inheritdoc />
    public async Task<string> AnalyzeImageAsync(byte[] imageBytes, string mimeType, bool doOcr, bool doDescription)
    {
        // Build the task prompt based on selected options
        var tasks = new List<string>();
        if (doOcr)         tasks.Add("extract ALL text visible in this image (OCR)");
        if (doDescription) tasks.Add("provide a clear, detailed description of what this image shows");

        if (tasks.Count == 0)
            return "Please select at least one analysis option.";

        var prompt = $"Please {string.Join(" and ", tasks)}. " +
                     "Be thorough and format the output clearly for a visually impaired user.";

        var imageBase64 = Convert.ToBase64String(imageBytes);

        var body = new
        {
            model      = Model,
            max_tokens = 2048,
            messages   = new[]
            {
                new
                {
                    role    = "user",
                    content = new object[]
                    {
                        new { type = "image", source = new { type = "base64", media_type = mimeType, data = imageBase64 } },
                        new { type = "text",  text   = prompt }
                    }
                }
            }
        };

        var json     = JsonSerializer.Serialize(body);
        var content  = new StringContent(json, Encoding.UTF8, "application/json");
        var response = await _http.PostAsync(ApiUrl, content);
        var result   = await response.Content.ReadAsStringAsync();

        using var doc = JsonDocument.Parse(result);
        var text      = doc.RootElement
                          .GetProperty("content")[0]
                          .GetProperty("text")
                          .GetString();

        return text ?? "Analysis could not be completed.";
    }
}
