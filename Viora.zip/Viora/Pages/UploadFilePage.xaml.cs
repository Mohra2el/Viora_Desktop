using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

public partial class UploadFilePage : ContentPage
{
    private readonly UploadFileViewModel  _vm;
    private readonly ILocalizationService _loc;

    public UploadFilePage(UploadFileViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    private void ApplyLocalization()
    {
        Title = _loc.Get("nav_upload");
        FlowDirection = _loc.IsArabic ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblTitle.Text    = _loc.Get("upload_title");
        lblDropHere.Text = _loc.Get("drop_file_here");
        lblFormats.Text  = _loc.Get("supported_formats");
        btnSelect.Text   = _loc.Get("select_file");
        lblRecent.Text   = _loc.Get("recent_uploads");
    }
}
