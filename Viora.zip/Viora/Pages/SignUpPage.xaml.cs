using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

public partial class SignUpPage : ContentPage
{
    private readonly SignUpViewModel    _vm;
    private readonly ILocalizationService _loc;

    public SignUpPage(SignUpViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
        ApplyLocalization();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    private void ApplyLocalization()
    {
        FlowDirection = _loc.IsArabic ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblTitle.Text      = _loc.Get("signup_title");
        lblName.Text       = _loc.Get("signup_name");
        lblEmail.Text      = _loc.Get("signup_email");
        lblPassword.Text   = _loc.Get("signup_password");
        lblConfirm.Text    = _loc.Get("signup_confirm");
        btnSignUp.Text     = _loc.Get("signup_button");
        lblHasAccount.Text = _loc.Get("signup_has_account");
        btnGoSignIn.Text   = _loc.Get("signin_link");

        entryName.Placeholder    = _loc.Get("signup_name");
        entryEmail.Placeholder   = _loc.Get("signup_email");
        entryPassword.Placeholder= _loc.Get("signup_password");
        entryConfirm.Placeholder = _loc.Get("signup_confirm");
    }

    private async void OnNameFocused(object s, FocusEventArgs e)    => await _vm.NameFocusedCommand.ExecuteAsync(null);
    private async void OnEmailFocused(object s, FocusEventArgs e)   => await _vm.EmailFocusedCommand.ExecuteAsync(null);
    private async void OnPasswordFocused(object s, FocusEventArgs e)=> await _vm.PasswordFocusedCommand.ExecuteAsync(null);
    private async void OnConfirmFocused(object s, FocusEventArgs e) => await _vm.ConfirmFocusedCommand.ExecuteAsync(null);
    private async void OnConfirmCompleted(object s, EventArgs e)     => await _vm.SignUpCommand.ExecuteAsync(null);
}
