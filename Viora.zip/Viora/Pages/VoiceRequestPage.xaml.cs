using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

public partial class VoiceRequestPage : ContentPage
{
    private readonly VoiceRequestViewModel _vm;
    private readonly ILocalizationService  _loc;

    public VoiceRequestPage(VoiceRequestViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    private void ApplyLocalization()
    {
        Title = _loc.Get("nav_voice_request");
        FlowDirection = _loc.IsArabic ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblTitle.Text     = _loc.Get("voice_assistant");
        lblSuggested.Text = _loc.Get("suggested_commands");
        lblCmd1.Text      = _loc.Get("cmd_new_request");
        lblCmd2.Text      = _loc.Get("cmd_view_messages");
        lblCmd3.Text      = _loc.Get("cmd_read_file");
    }
}
