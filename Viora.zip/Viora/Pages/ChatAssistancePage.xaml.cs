using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

public partial class ChatAssistancePage : ContentPage
{
    private readonly ChatAssistanceViewModel _vm;
    private readonly ILocalizationService    _loc;

    public ChatAssistancePage(ChatAssistanceViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();

        // Scroll to the bottom when the message list changes
        _vm.Messages.CollectionChanged += async (_, _) => await ScrollToBottom();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    private void ApplyLocalization()
    {
        Title = _loc.Get("nav_chat");
        FlowDirection = _loc.IsArabic ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblAIName.Text     = _loc.Get("ai_assistant");
        lblAISubtitle.Text = _loc.Get("ai_subtitle");
        lblOnline.Text     = _loc.Get("ai_online");
        entryInput.Placeholder = _loc.Get("chat_placeholder");

        chipLabel.Text      = _loc.Get("quick_how_label");
        chipMedication.Text = _loc.Get("quick_medication");
        chipWhat.Text       = _loc.Get("quick_what_can");
        chipVoice.Text      = _loc.Get("quick_voice_input");
    }

    /// <summary>Pressing Return in the input box sends the message.</summary>
    private async void OnInputCompleted(object sender, EventArgs e)
        => await _vm.SendMessageCommand.ExecuteAsync(null);

    private async Task ScrollToBottom()
    {
        if (_vm.Messages.Count == 0) return;
        await Task.Delay(100); // Let the list render
        msgList.ScrollTo(_vm.Messages[^1], ScrollToPosition.End, animate: true);
    }
}
