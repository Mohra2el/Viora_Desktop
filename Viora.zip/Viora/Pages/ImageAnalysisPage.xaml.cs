using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

public partial class ImageAnalysisPage : ContentPage
{
    private readonly ImageAnalysisViewModel _vm;
    private readonly ILocalizationService   _loc;

    public ImageAnalysisPage(ImageAnalysisViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    private void ApplyLocalization()
    {
        Title = _loc.Get("nav_image_analysis");
        FlowDirection = _loc.IsArabic ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblUpload.Text   = _loc.Get("upload_image");
        lblDropHere.Text = _loc.Get("drop_image_here");
        lblFormats.Text  = _loc.Get("supported_image_formats");
        btnSelect.Text   = _loc.Get("select_image");
        lblOptions.Text  = _loc.Get("analysis_options");
        lblOcr.Text      = _loc.Get("ocr_extract");
        lblDesc.Text     = _loc.Get("ai_description");
        btnAnalyze.Text  = _loc.Get("analyze_button");
    }
}
