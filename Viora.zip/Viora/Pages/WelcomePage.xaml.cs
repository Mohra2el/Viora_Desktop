using Viora.ViewModels;

namespace Viora.Pages;

/// <summary>
/// WelcomePage code-behind.
/// Wires keyboard shortcuts (1 = English, 2 = Arabic) and
/// triggers voice guidance when the page appears.
/// </summary>
public partial class WelcomePage : ContentPage
{
    private readonly WelcomeViewModel _vm;

    public WelcomePage(WelcomeViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.OnPageAppeared();
    }

    // ── Keyboard shortcut handling ────────────────────────────────────

    /// <summary>
    /// Handle physical key presses:
    /// "1" → English, "2" → Arabic, Enter → English (default).
    /// </summary>
    protected override void OnHandlerChanged()
    {
        base.OnHandlerChanged();

#if WINDOWS
        // Wire keyboard handler on Windows
        if (Handler?.PlatformView is Microsoft.UI.Xaml.UIElement element)
        {
            element.KeyDown += async (s, e) =>
            {
                if (e.Key == Windows.System.VirtualKey.Number1 ||
                    e.Key == Windows.System.VirtualKey.NumberPad1)
                {
                    await _vm.SelectEnglishCommand.ExecuteAsync(null);
                }
                else if (e.Key == Windows.System.VirtualKey.Number2 ||
                         e.Key == Windows.System.VirtualKey.NumberPad2)
                {
                    await _vm.SelectArabicCommand.ExecuteAsync(null);
                }
            };
        }
#endif
    }
}
