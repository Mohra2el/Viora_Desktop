using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

/// <summary>
/// HomePage code-behind.
/// Applies localization to all named UI elements and
/// delegates lifecycle events to the ViewModel.
/// </summary>
public partial class HomePage : ContentPage
{
    private readonly HomeViewModel      _vm;
    private readonly ILocalizationService _loc;

    public HomePage(HomeViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
        ApplyLocalization();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();

        // Update avatar with real user initials
        lblAvatar.Text = IPlatformApplication.Current!
            .Services.GetRequiredService<IAuthService>()
            .CurrentUser?.Initials ?? "?";
    }

    private void ApplyLocalization()
    {
        var rtl = _loc.IsArabic;
        FlowDirection = rtl ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        // Sidebar nav labels
        btnNavHome.Text   = $"🏠  {_loc.Get("nav_home")}";
        btnNavVoice.Text  = $"🎤  {_loc.Get("nav_voice_request")}";
        btnNavChat.Text   = $"💬  {_loc.Get("nav_chat")}";
        btnNavUpload.Text = $"📄  {_loc.Get("nav_upload")}";
        btnNavImage.Text  = $"🖼️  {_loc.Get("nav_image_analysis")}";
        btnLogout.Text    = $"↪  {_loc.Get("nav_logout")}";

        // Top bar
        btnVoiceToggle.Text = $"🎤  {_loc.Get("voice_request")}";

        // Main content
        lblWelcome.Text        = $"{_loc.Get("home_welcome")}, {_vm.UserName}";
        lblRole.Text           = _loc.Get("home_role");
        lblQuickActions.Text   = _loc.Get("quick_actions");
        lblRecentUploads.Text  = _loc.Get("recent_uploads");

        // Quick action buttons
        lblQAVoice.Text      = _loc.Get("voice_request");
        lblQAUpload.Text     = _loc.Get("upload_file");
        lblQAImage.Text      = _loc.Get("image_analysis");
        lblQAQuickVoice.Text = _loc.Get("quick_voice_command");

        btnUploadImage.Text  = _loc.Get("upload_file");
    }
}
