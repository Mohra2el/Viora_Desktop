using Viora.Services;
using Viora.ViewModels;

namespace Viora.Pages;

/// <summary>
/// SignInPage code-behind.
/// Updates all labels when the language changes and
/// delegates field-focus events to the ViewModel for voice guidance.
/// </summary>
public partial class SignInPage : ContentPage
{
    private readonly SignInViewModel   _vm;
    private readonly ILocalizationService _loc;

    public SignInPage(SignInViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm  = vm;
        _loc = IPlatformApplication.Current!.Services.GetRequiredService<ILocalizationService>();
        ApplyLocalization();
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        ApplyLocalization();
        await _vm.OnPageAppeared();
    }

    // ── Localization ──────────────────────────────────────────────────

    /// <summary>Update all text labels using the active language.</summary>
    private void ApplyLocalization()
    {
        // Set RTL for Arabic
        var rtl = _loc.IsArabic;
        FlowDirection = rtl ? FlowDirection.RightToLeft : FlowDirection.LeftToRight;

        lblTitle.Text        = _loc.Get("signin_title");
        lblEmail.Text        = _loc.Get("signin_email");
        lblPassword.Text     = _loc.Get("signin_password");
        btnSignIn.Text       = _loc.Get("signin_button");
        lblNoAccount.Text    = _loc.Get("signin_no_account");
        btnGoSignUp.Text     = _loc.Get("signup_link");

        entryEmail.Placeholder    = _loc.Get("signin_email");
        entryPassword.Placeholder = _loc.Get("signin_password");
    }

    // ── Field focus → voice guidance ──────────────────────────────────

    private async void OnEmailFocused(object sender, FocusEventArgs e)
        => await _vm.EmailFocusedCommand.ExecuteAsync(null);

    private async void OnPasswordFocused(object sender, FocusEventArgs e)
        => await _vm.PasswordFocusedCommand.ExecuteAsync(null);

    /// <summary>Pressing Enter/Return in the password field submits the form.</summary>
    private async void OnPasswordCompleted(object sender, EventArgs e)
        => await _vm.SignInCommand.ExecuteAsync(null);
}
