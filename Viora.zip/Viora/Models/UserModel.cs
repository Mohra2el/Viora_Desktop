namespace Viora.Models;

/// <summary>Represents a signed-in user.</summary>
public class UserModel
{
    public string Name  { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Role  { get; set; } = "Visually Impaired User";

    /// <summary>Initials shown in the avatar circle (e.g. "JD" for John Doe).</summary>
    public string Initials => string.Concat(
        Name.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Take(2)
            .Select(w => w[0].ToString().ToUpper()));
}
