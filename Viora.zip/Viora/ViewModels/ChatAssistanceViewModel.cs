using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>A single chat bubble in the conversation list.</summary>
public partial class ChatBubble : ObservableObject
{
    public string Text      { get; init; } = string.Empty;
    public string Time      { get; init; } = string.Empty;
    public bool   IsUser    { get; init; }   // true = right side, false = AI left side
}

/// <summary>
/// ChatAssistanceViewModel powers the AI chat screen.
/// It keeps conversation history and calls the AI service for responses.
/// </summary>
public partial class ChatAssistanceViewModel : BaseViewModel
{
    private readonly IAIService _ai;

    // The full conversation displayed in the UI
    public System.Collections.ObjectModel.ObservableCollection<ChatBubble> Messages { get; } = [];

    // The history sent to the AI on each turn (role + content pairs)
    private readonly List<ChatMessage> _history = [];

    [ObservableProperty] private string _inputText = string.Empty;

    public ChatAssistanceViewModel(ILocalizationService localization, IVoiceGuidanceService voice, IAIService ai)
        : base(localization, voice)
    {
        _ai = ai;
    }

    public async Task OnPageAppeared()
    {
        // Add the opening AI message
        if (Messages.Count == 0)
        {
            var greeting = "Hello! I'm your AI assistant. I can help you with questions, " +
                           "clarifications, or anything you need assistance with. How can I help you today?";
            AddAiMessage(greeting);
            await Task.Delay(400);
            await Voice.SpeakAsync(greeting);
        }
        else
        {
            await Voice.SpeakAsync(L("chat_page_prompt"));
        }
    }

    /// <summary>Send the typed message to the AI.</summary>
    [RelayCommand]
    public async Task SendMessage()
    {
        var text = InputText.Trim();
        if (string.IsNullOrEmpty(text) || IsBusy) return;

        InputText = string.Empty;

        // Show user bubble
        Messages.Add(new ChatBubble { Text = text, Time = DateTime.Now.ToString("hh:mm tt"), IsUser = true });
        _history.Add(new ChatMessage("user", text));

        IsBusy = true;
        await Voice.SpeakAsync(L("loading"));

        try
        {
            var reply = await _ai.ChatAsync(text, _history);
            _history.Add(new ChatMessage("assistant", reply));
            AddAiMessage(reply);
            await Voice.SpeakAsync(reply); // Read the AI response aloud
        }
        catch
        {
            var err = L("error_generic");
            AddAiMessage(err);
            await Voice.SpeakAsync(err);
        }
        finally
        {
            IsBusy = false;
        }
    }

    /// <summary>Handle tapping one of the quick-suggestion chips.</summary>
    [RelayCommand]
    public async Task QuickSuggestion(string suggestion)
    {
        InputText = suggestion;
        await SendMessageCommand.ExecuteAsync(null);
    }

    // ── Private helpers ───────────────────────────────────────────────

    private void AddAiMessage(string text) =>
        Messages.Add(new ChatBubble
        {
            Text   = text,
            Time   = DateTime.Now.ToString("hh:mm tt"),
            IsUser = false
        });
}
