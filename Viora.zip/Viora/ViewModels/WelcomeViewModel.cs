using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Pages;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// WelcomeViewModel handles the splash/language-selection screen.
/// It speaks the welcome prompt and responds to key presses 1 (EN) or 2 (AR).
/// </summary>
public partial class WelcomeViewModel : BaseViewModel
{
    public WelcomeViewModel(ILocalizationService localization, IVoiceGuidanceService voice)
        : base(localization, voice) { }

    /// <summary>
    /// Called when the page appears.
    /// Greet the user and prompt for language selection.
    /// </summary>
    public async Task OnPageAppeared()
    {
        // Brief pause so the UI finishes rendering before speech starts
        await Task.Delay(600);

        // Speak both language options so the user knows what to do
        await Voice.SpeakAsync(
            "Welcome to Viora, your accessibility platform. " +
            "Press 1 for English or press 2 for Arabic."
        );
    }

    /// <summary>Select English and navigate to Sign In.</summary>
    [RelayCommand]
    public async Task SelectEnglish()
    {
        Localization.SetLanguage("en");
        await Voice.SpeakAsync("English selected. Taking you to sign in.");
        await NavigateToSignIn();
    }

    /// <summary>Select Arabic and navigate to Sign In.</summary>
    [RelayCommand]
    public async Task SelectArabic()
    {
        Localization.SetLanguage("ar");
        await Voice.SpeakAsync("تم اختيار اللغة العربية. سننتقل إلى صفحة تسجيل الدخول.");
        await NavigateToSignIn();
    }

    // ── Private helpers ───────────────────────────────────────────────

    private static async Task NavigateToSignIn()
    {
        // Resolve from DI and push onto the navigation stack
        var vm   = IPlatformApplication.Current!.Services.GetRequiredService<SignInViewModel>();
        var page = new SignInPage(vm);
        await Shell.Current.Navigation.PushAsync(page);
    }
}
