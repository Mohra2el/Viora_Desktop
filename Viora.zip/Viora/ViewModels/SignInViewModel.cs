using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Pages;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// SignInViewModel handles email/password authentication.
/// Voice guidance walks the user through each field and action.
/// </summary>
public partial class SignInViewModel : BaseViewModel
{
    private readonly IAuthService _auth;

    [ObservableProperty] private string _email    = string.Empty;
    [ObservableProperty] private string _password = string.Empty;
    [ObservableProperty] private string _errorMessage = string.Empty;

    public SignInViewModel(ILocalizationService localization, IVoiceGuidanceService voice, IAuthService auth)
        : base(localization, voice)
    {
        _auth = auth;
    }

    public async Task OnPageAppeared()
    {
        await Task.Delay(400);
        // Read the page instructions aloud
        await Voice.SpeakAsync(L("signin_voice_prompt"));
    }

    /// <summary>Called when the Email field receives focus — announce it.</summary>
    [RelayCommand]
    public async Task EmailFocused()
        => await Voice.SpeakAsync(L("signin_email"));

    /// <summary>Called when the Password field receives focus — announce it.</summary>
    [RelayCommand]
    public async Task PasswordFocused()
        => await Voice.SpeakAsync(L("signin_password"));

    /// <summary>Attempt sign in with the entered credentials.</summary>
    [RelayCommand]
    public async Task SignIn()
    {
        if (IsBusy) return;
        IsBusy       = true;
        ErrorMessage = string.Empty;

        await Voice.SpeakAsync(L("loading"));

        var (success, message) = await _auth.SignInAsync(Email, Password);

        IsBusy = false;

        if (success)
        {
            await Voice.SpeakAsync($"{L("home_welcome")} {_auth.CurrentUser?.Name}");
            await NavigateToHome();
        }
        else
        {
            ErrorMessage = message;
            await Voice.SpeakAsync(message);
        }
    }

    /// <summary>Navigate to the Sign Up page.</summary>
    [RelayCommand]
    public async Task GoToSignUp()
    {
        await Voice.SpeakAsync(L("signup_title"));
        var vm   = IPlatformApplication.Current!.Services.GetRequiredService<SignUpViewModel>();
        var page = new SignUpPage(vm);
        await Shell.Current.Navigation.PushAsync(page);
    }

    // ── Private ───────────────────────────────────────────────────────

    private static async Task NavigateToHome()
    {
        var vm   = IPlatformApplication.Current!.Services.GetRequiredService<HomeViewModel>();
        var page = new HomePage(vm);

        // Replace the navigation stack so Back cannot return to sign-in
        Shell.Current.Navigation.InsertPageBefore(page, Shell.Current.Navigation.NavigationStack[0]);
        await Shell.Current.Navigation.PopToRootAsync();
    }
}
