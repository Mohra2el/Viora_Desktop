using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// VoiceRequestViewModel manages the voice assistant page.
/// It shows suggested commands and plays back results via TTS.
/// (SpeechToText integration points are marked for future implementation.)
/// </summary>
public partial class VoiceRequestViewModel : BaseViewModel
{
    [ObservableProperty] private bool   _isListening      = false;
    [ObservableProperty] private string _recognizedText   = string.Empty;
    [ObservableProperty] private string _responseText     = string.Empty;
    [ObservableProperty] private string _micButtonLabel   = string.Empty;

    public VoiceRequestViewModel(ILocalizationService localization, IVoiceGuidanceService voice)
        : base(localization, voice) { }

    public async Task OnPageAppeared()
    {
        MicButtonLabel = L("tap_to_speak");
        await Task.Delay(400);
        await Voice.SpeakAsync(L("voice_page_prompt"));
    }

    /// <summary>
    /// Toggle microphone on/off.
    /// STT (Speech-to-Text) is platform-specific — hook in here.
    /// </summary>
    [RelayCommand]
    public async Task ToggleMicrophone()
    {
        if (IsListening)
        {
            // ── Stop listening ────────────────────────────────────────
            IsListening    = false;
            MicButtonLabel = L("tap_to_speak");

            // TODO: Stop the STT engine and process RecognizedText
            // Example: var result = await SpeechToText.Default.StopListenAsync();
            // RecognizedText = result;
            // Then call AI/handle the command...

            await Voice.SpeakAsync("Stopped listening.");
        }
        else
        {
            // ── Start listening ───────────────────────────────────────
            IsListening    = true;
            MicButtonLabel = "Listening…";
            RecognizedText = string.Empty;
            ResponseText   = string.Empty;

            await Voice.SpeakAsync("Listening. Please speak your command.");

            // TODO: Start STT engine
            // Example: await SpeechToText.Default.StartListenAsync(CultureInfo.CurrentCulture, new Progress<string>(...));
        }
    }

    /// <summary>Speak a suggested command so the user knows their options.</summary>
    [RelayCommand]
    public async Task SpeakSuggestion(string suggestion)
        => await Voice.SpeakAsync(suggestion);
}
