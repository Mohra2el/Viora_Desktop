using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Pages;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// HomeViewModel drives the dashboard screen.
/// It exposes the user's name, quick-action commands, and navigation to sub-pages.
/// </summary>
public partial class HomeViewModel : BaseViewModel
{
    private readonly IAuthService _auth;

    [ObservableProperty] private string _userName    = "User";
    [ObservableProperty] private string _userInitials = "U";
    [ObservableProperty] private string _userRole    = string.Empty;

    public HomeViewModel(ILocalizationService localization, IVoiceGuidanceService voice, IAuthService auth)
        : base(localization, voice)
    {
        _auth = auth;
    }

    /// <summary>Populate user info and speak a welcome prompt.</summary>
    public async Task OnPageAppeared()
    {
        if (_auth.CurrentUser is { } user)
        {
            UserName     = user.Name;
            UserInitials = user.Initials;
            UserRole     = L("home_role");
        }

        await Task.Delay(400);
        await Voice.SpeakAsync($"{L("home_welcome")}, {UserName}. {L("home_voice_prompt")}");
    }

    // ── Quick-action commands ─────────────────────────────────────────

    [RelayCommand]
    public async Task OpenVoiceRequest()
    {
        await Voice.SpeakAsync(L("nav_voice_request"));
        await PushPage<VoiceRequestViewModel, VoiceRequestPage>();
    }

    [RelayCommand]
    public async Task OpenUploadFile()
    {
        await Voice.SpeakAsync(L("nav_upload"));
        await PushPage<UploadFileViewModel, UploadFilePage>();
    }

    [RelayCommand]
    public async Task OpenImageAnalysis()
    {
        await Voice.SpeakAsync(L("nav_image_analysis"));
        await PushPage<ImageAnalysisViewModel, ImageAnalysisPage>();
    }

    [RelayCommand]
    public async Task OpenChat()
    {
        await Voice.SpeakAsync(L("nav_chat"));
        await PushPage<ChatAssistanceViewModel, ChatAssistancePage>();
    }

    [RelayCommand]
    public async Task Logout()
    {
        var confirm = await Shell.Current.DisplayAlert(
            L("nav_logout"),
            L("logout_confirm"),
            L("yes"),
            L("no")
        );

        if (!confirm) return;

        _auth.SignOut();
        await Voice.SpeakAsync("You have been signed out. Goodbye.");

        // Return to the welcome/sign-in screen
        Application.Current!.MainPage = new NavigationPage(
            new WelcomePage(IPlatformApplication.Current!.Services.GetRequiredService<WelcomeViewModel>())
        )
        {
            BarBackgroundColor = Colors.Black,
            BarTextColor       = Colors.White
        };
    }

    // ── Sidebar focus announcements ───────────────────────────────────

    [RelayCommand] public async Task FocusHome()          => await Voice.SpeakAsync(L("nav_home"));
    [RelayCommand] public async Task FocusVoiceRequest()  => await Voice.SpeakAsync(L("nav_voice_request"));
    [RelayCommand] public async Task FocusChat()          => await Voice.SpeakAsync(L("nav_chat"));
    [RelayCommand] public async Task FocusUpload()        => await Voice.SpeakAsync(L("nav_upload"));
    [RelayCommand] public async Task FocusImageAnalysis() => await Voice.SpeakAsync(L("nav_image_analysis"));
    [RelayCommand] public async Task FocusLogout()        => await Voice.SpeakAsync(L("nav_logout"));

    // ── Helper: resolve VM + Page from DI and push ────────────────────

    private static async Task PushPage<TViewModel, TPage>()
        where TViewModel : class
        where TPage : Page
    {
        var services = IPlatformApplication.Current!.Services;
        var vm       = services.GetRequiredService<TViewModel>();
        var page     = (TPage)Activator.CreateInstance(typeof(TPage), vm)!;
        await Shell.Current.Navigation.PushAsync(page);
    }
}
