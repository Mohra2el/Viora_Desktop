using CommunityToolkit.Mvvm.ComponentModel;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// BaseViewModel provides shared functionality for all ViewModels:
/// - Property change notifications (via ObservableObject)
/// - Voice guidance helper
/// - Localization helper
/// - Busy state tracking
/// </summary>
public partial class BaseViewModel : ObservableObject
{
    protected readonly ILocalizationService Localization;
    protected readonly IVoiceGuidanceService Voice;

    // Backing field + auto-generated IsBusy property
    [ObservableProperty]
    private bool _isBusy;

    // Backing field + auto-generated StatusMessage property
    [ObservableProperty]
    private string _statusMessage = string.Empty;

    protected BaseViewModel(ILocalizationService localization, IVoiceGuidanceService voice)
    {
        Localization = localization;
        Voice        = voice;
    }

    /// <summary>Shorthand for localized strings.</summary>
    protected string L(string key) => Localization.Get(key);

    /// <summary>Speak a localized string aloud.</summary>
    protected Task SpeakAsync(string key) => Voice.SpeakAsync(L(key));

    /// <summary>Speak a raw (non-localized) string.</summary>
    protected Task SpeakRawAsync(string text) => Voice.SpeakAsync(text);
}
