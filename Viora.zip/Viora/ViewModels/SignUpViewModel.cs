using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Pages;
using Viora.Services;

namespace Viora.ViewModels;

/// <summary>
/// SignUpViewModel handles new-account creation.
/// Each field focus triggers a spoken label for accessibility.
/// </summary>
public partial class SignUpViewModel : BaseViewModel
{
    private readonly IAuthService _auth;

    [ObservableProperty] private string _name           = string.Empty;
    [ObservableProperty] private string _email          = string.Empty;
    [ObservableProperty] private string _password       = string.Empty;
    [ObservableProperty] private string _confirmPassword = string.Empty;
    [ObservableProperty] private string _errorMessage   = string.Empty;

    public SignUpViewModel(ILocalizationService localization, IVoiceGuidanceService voice, IAuthService auth)
        : base(localization, voice)
    {
        _auth = auth;
    }

    public async Task OnPageAppeared()
    {
        await Task.Delay(400);
        await Voice.SpeakAsync(L("signup_voice_prompt"));
    }

    [RelayCommand] public async Task NameFocused()    => await Voice.SpeakAsync(L("signup_name"));
    [RelayCommand] public async Task EmailFocused()   => await Voice.SpeakAsync(L("signup_email"));
    [RelayCommand] public async Task PasswordFocused()=> await Voice.SpeakAsync(L("signup_password"));
    [RelayCommand] public async Task ConfirmFocused() => await Voice.SpeakAsync(L("signup_confirm"));

    [RelayCommand]
    public async Task SignUp()
    {
        if (IsBusy) return;

        // Validate passwords match before calling the service
        if (Password != ConfirmPassword)
        {
            ErrorMessage = "Passwords do not match.";
            await Voice.SpeakAsync(ErrorMessage);
            return;
        }

        IsBusy       = true;
        ErrorMessage = string.Empty;
        await Voice.SpeakAsync(L("loading"));

        var (success, message) = await _auth.SignUpAsync(Name, Email, Password);
        IsBusy = false;

        if (success)
        {
            await Voice.SpeakAsync($"Account created. {L("home_welcome")} {Name}");
            await NavigateToHome();
        }
        else
        {
            ErrorMessage = message;
            await Voice.SpeakAsync(message);
        }
    }

    [RelayCommand]
    public async Task GoToSignIn()
    {
        await Shell.Current.Navigation.PopAsync();
    }

    private static async Task NavigateToHome()
    {
        var vm   = IPlatformApplication.Current!.Services.GetRequiredService<HomeViewModel>();
        var page = new HomePage(vm);
        Shell.Current.Navigation.InsertPageBefore(page, Shell.Current.Navigation.NavigationStack[0]);
        await Shell.Current.Navigation.PopToRootAsync();
    }
}
