using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Viora.Services;

namespace Viora.ViewModels;

// ═══════════════════════════════════════════════════════════════════════════
// UploadFileViewModel
// ═══════════════════════════════════════════════════════════════════════════

/// <summary>
/// UploadFileViewModel handles document uploads (PDF, DOCX, TXT, images).
/// The selected file is shown in a "Recent Uploads" list and can be read
/// back to the user via the AI service.
/// </summary>
public partial class UploadFileViewModel : BaseViewModel
{
    [ObservableProperty] private string _selectedFileName = string.Empty;
    [ObservableProperty] private bool   _fileSelected     = false;

    public System.Collections.ObjectModel.ObservableCollection<string> RecentFiles { get; } = [];

    public UploadFileViewModel(ILocalizationService localization, IVoiceGuidanceService voice)
        : base(localization, voice) { }

    public async Task OnPageAppeared()
    {
        await Task.Delay(400);
        await Voice.SpeakAsync(L("upload_page_prompt"));
    }

    [RelayCommand]
    public async Task PickFile()
    {
        await Voice.SpeakAsync("Opening file picker.");

        try
        {
            var result = await FilePicker.Default.PickAsync(new PickOptions
            {
                PickerTitle       = L("select_file"),
                FileTypes         = FilePickerFileType.Images, // extend as needed
            });

            if (result is null)
            {
                await Voice.SpeakAsync("No file was selected.");
                return;
            }

            SelectedFileName = result.FileName;
            FileSelected     = true;

            RecentFiles.Insert(0, result.FileName);

            await Voice.SpeakAsync($"File selected: {result.FileName}. Ready to upload.");
        }
        catch (Exception ex)
        {
            await Voice.SpeakAsync(L("error_generic"));
            System.Diagnostics.Debug.WriteLine($"[Upload] {ex.Message}");
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// ImageAnalysisViewModel
// ═══════════════════════════════════════════════════════════════════════════

/// <summary>
/// ImageAnalysisViewModel handles image upload and AI-powered analysis
/// (OCR text extraction and/or AI scene description).
/// </summary>
public partial class ImageAnalysisViewModel : BaseViewModel
{
    private readonly IAIService _ai;

    [ObservableProperty] private ImageSource? _selectedImage;
    [ObservableProperty] private bool         _imageSelected  = false;
    [ObservableProperty] private bool         _doOcr          = true;
    [ObservableProperty] private bool         _doDescription  = true;
    [ObservableProperty] private string       _analysisResult = string.Empty;

    // Store raw bytes for the API call
    private byte[]? _imageBytes;
    private string  _imageMimeType = "image/jpeg";

    public ImageAnalysisViewModel(ILocalizationService localization, IVoiceGuidanceService voice, IAIService ai)
        : base(localization, voice)
    {
        _ai = ai;
    }

    public async Task OnPageAppeared()
    {
        await Task.Delay(400);
        await Voice.SpeakAsync(L("image_page_prompt"));
    }

    [RelayCommand]
    public async Task PickImage()
    {
        await Voice.SpeakAsync("Opening image picker.");

        try
        {
            var result = await MediaPicker.Default.PickPhotoAsync();
            if (result is null)
            {
                await Voice.SpeakAsync("No image was selected.");
                return;
            }

            // Load the image into memory
            using var stream = await result.OpenReadAsync();
            using var ms     = new MemoryStream();
            await stream.CopyToAsync(ms);
            _imageBytes    = ms.ToArray();
            _imageMimeType = result.ContentType;

            SelectedImage = ImageSource.FromStream(() => new MemoryStream(_imageBytes));
            ImageSelected = true;

            await Voice.SpeakAsync($"Image selected: {result.FileName}. Tap Analyze Image to continue.");
        }
        catch (Exception ex)
        {
            await Voice.SpeakAsync(L("error_generic"));
            System.Diagnostics.Debug.WriteLine($"[ImageAnalysis] {ex.Message}");
        }
    }

    [RelayCommand]
    public async Task AnalyzeImage()
    {
        if (_imageBytes is null)
        {
            await Voice.SpeakAsync("Please select an image first.");
            return;
        }

        IsBusy = true;
        await Voice.SpeakAsync(L("loading"));

        try
        {
            AnalysisResult = await _ai.AnalyzeImageAsync(_imageBytes, _imageMimeType, DoOcr, DoDescription);
            await Voice.SpeakAsync(AnalysisResult);
        }
        catch
        {
            AnalysisResult = L("error_generic");
            await Voice.SpeakAsync(AnalysisResult);
        }
        finally
        {
            IsBusy = false;
        }
    }

    [RelayCommand]
    public async Task ToggleOcr()
    {
        DoOcr = !DoOcr;
        await Voice.SpeakAsync($"OCR extraction {(DoOcr ? "enabled" : "disabled")}.");
    }

    [RelayCommand]
    public async Task ToggleDescription()
    {
        DoDescription = !DoDescription;
        await Voice.SpeakAsync($"AI description {(DoDescription ? "enabled" : "disabled")}.");
    }
}
