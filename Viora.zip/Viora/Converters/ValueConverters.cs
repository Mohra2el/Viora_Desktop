using System.Globalization;

namespace Viora.Converters;

/// <summary>
/// Returns true when the bool binding value is false (and vice versa).
/// Usage: IsVisible="{Binding IsBusy, Converter={StaticResource InverseBoolConverter}}"
/// </summary>
public class InverseBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is bool b && !b;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is bool b && !b;
}

/// <summary>
/// Returns true when the string binding value is not null or empty.
/// Usage: IsVisible="{Binding ErrorMessage, Converter={StaticResource StringNotEmptyConverter}}"
/// </summary>
public class StringNotEmptyConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => !string.IsNullOrEmpty(value as string);

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotImplementedException();
}
